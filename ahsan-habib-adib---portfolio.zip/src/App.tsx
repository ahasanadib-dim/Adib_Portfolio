import { motion } from "motion/react";
import { 
  Github, 
  Mail, 
  Phone, 
  MapPin, 
  ExternalLink, 
  Palette, 
  Layout, 
  Video, 
  Share2, 
  Cpu, 
  Code,
  GraduationCap,
  Briefcase,
  ChevronDown
} from "lucide-react";
import { useState, useEffect } from "react";

const fadeIn = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

export default function App() {
  const [activeSection, setActiveSection] = useState("home");
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
      
      const sections = ["home", "about", "portfolio", "contact"];
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top <= 100 && rect.bottom >= 100) {
            setActiveSection(section);
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { id: "home", label: "Home" },
    { id: "about", label: "About" },
    { id: "portfolio", label: "Work" },
    { id: "contact", label: "Contact" }
  ];

  return (
    <div className="min-h-screen bg-[#fafafa] text-slate-900 font-sans selection:bg-orange-100 selection:text-orange-600">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? "bg-white/80 backdrop-blur-md border-b border-slate-100 py-4" : "bg-transparent py-6"}`}>
        <div className="max-w-6xl mx-auto px-6 flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="text-xl font-bold tracking-tighter"
          >
            ADIB<span className="text-orange-500">.</span>
          </motion.div>
          <div className="hidden md:flex gap-8">
            {navItems.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                className={`text-sm font-medium transition-colors hover:text-orange-500 ${activeSection === item.id ? "text-orange-500" : "text-slate-500"}`}
              >
                {item.label}
              </a>
            ))}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex flex-col justify-center items-center text-center px-6 pt-20 overflow-hidden">
        {/* Background Decorative Elements */}
        <div className="absolute top-1/4 -left-20 w-80 h-80 bg-orange-100 rounded-full blur-[100px] opacity-60 pointer-events-none" />
        <div className="absolute bottom-1/4 -right-20 w-80 h-80 bg-orange-100 rounded-full blur-[100px] opacity-60 pointer-events-none" />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="relative z-10"
        >
          <p className="text-orange-600 font-mono text-sm tracking-widest mb-4 uppercase">Canva Designer & Software Engineer</p>
          <h1 className="text-6xl md:text-8xl font-black tracking-tight mb-6 text-slate-900">
            Ahsan Habib <br /> <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-orange-400">Adib</span>
          </h1>
          <p className="max-w-xl mx-auto text-slate-500 text-lg md:text-xl leading-relaxed mb-10">
            Creative designer crafting modern visual identities, social media content, 
            and digital experiences with a focus on modern design trends.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="#portfolio" 
              className="px-8 py-4 bg-slate-900 text-white rounded-full font-medium hover:bg-slate-800 transition-all shadow-lg shadow-slate-200"
            >
              View My Work
            </a>
            <a 
              href="#contact" 
              className="px-8 py-4 bg-white border border-slate-200 text-slate-900 rounded-full font-medium hover:bg-slate-50 transition-all"
            >
              Get in Touch
            </a>
          </div>
        </motion.div>

        <motion.div 
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-slate-300"
        >
          <ChevronDown size={32} />
        </motion.div>
      </section>

      {/* About & Skills Section */}
      <section id="about" className="py-32 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-20 items-start">
            <motion.div {...fadeIn}>
              <h2 className="text-4xl font-bold tracking-tight mb-8">About Me</h2>
              <p className="text-slate-600 text-lg leading-relaxed mb-8">
                I'm a Bachelor of Software Engineering student at <span className="font-semibold text-slate-900">Daffodil International University</span>. 
                My passion lies at the intersection of technology and design. 
                As a Canva Designer, I've helped numerous brands and buying houses transform their online presence.
              </p>
              
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-orange-50 flex items-center justify-center shrink-0">
                    <GraduationCap className="text-orange-500" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900">Education</h4>
                    <p className="text-slate-500 text-sm">B.Sc in Software Engineering, DIU</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-orange-50 flex items-center justify-center shrink-0">
                    <Briefcase className="text-orange-500" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900">Experience</h4>
                    <p className="text-slate-500 text-sm">Garment Buying Houses & Freelance Design</p>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div {...fadeIn}>
              <h2 className="text-4xl font-bold tracking-tight mb-8">Toolkit</h2>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { name: "Canva", icon: Palette },
                  { name: "CapCut", icon: Video },
                  { name: "UI Design", icon: Layout },
                  { name: "Social Content", icon: Share2 },
                  { name: "AI Tools", icon: Cpu },
                  { name: "HTML Core", icon: Code }
                ].map((skill, index) => (
                  <div key={index} className="p-6 rounded-3xl bg-slate-50 border border-slate-100 hover:border-orange-200 transition-colors group">
                    <skill.icon className="text-slate-400 mb-4 group-hover:text-orange-500 transition-colors" />
                    <h4 className="font-bold text-slate-900">{skill.name}</h4>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-32 bg-[#fafafa]">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">Featured Work</h2>
            <p className="text-slate-500 max-w-2xl mx-auto">
              A selection of projects where I've blended creative design with strategic brand goals.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { 
                title: "Social Media Posts", 
                desc: "Restaurant promo, ecommerce ads, and tech content.", 
                tag: "Social Media" 
              },
              { 
                title: "Custom Thumbnails", 
                desc: "High-CTR designs for Podcasts, Tech, and Gaming channels.", 
                tag: "Video Marketing" 
              },
              { 
                title: "Visual Branding", 
                desc: "Event posters, sale banners, and gym marketing materials.", 
                tag: "Print & Digital" 
              },
              { 
                title: "Presentation Design", 
                desc: "Professional decks for Ostad App and Sourcing companies.", 
                tag: "Corporate" 
              },
              { 
                title: "Buying House Online", 
                desc: "Growing the digital footprint for garment exporters.", 
                tag: "Strategic" 
              },
              { 
                title: "AI Assisted Design", 
                desc: "Using cutting-edge AI tools to enhance visual assets.", 
                tag: "Innovation" 
              }
            ].map((item, index) => (
              <motion.div
                key={index}
                variants={fadeIn}
                initial="initial"
                whileInView="animate"
                viewport={{ once: true }}
                className="group relative bg-white p-8 rounded-[2rem] border border-slate-100 hover:shadow-2xl hover:shadow-orange-100/50 transition-all duration-500 overflow-hidden"
              >
                <div className="relative z-10">
                  <span className="inline-block px-3 py-1 bg-orange-50 text-orange-600 text-xs font-bold rounded-full mb-6">
                    {item.tag}
                  </span>
                  <h3 className="text-xl font-bold mb-3 text-slate-900 group-hover:text-orange-600 transition-colors">{item.title}</h3>
                  <p className="text-slate-500 text-sm leading-relaxed mb-6">{item.desc}</p>
                  <button className="flex items-center gap-2 text-sm font-bold text-slate-900 group-hover:gap-4 transition-all">
                    View Details <ExternalLink size={14} />
                  </button>
                </div>
                <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-orange-50 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-700" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-32 bg-slate-900 text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-orange-500/10 skew-x-12 translate-x-1/2 pointer-events-none" />
        
        <div className="max-w-6xl mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-20">
            <div>
              <h2 className="text-5xl font-black tracking-tight mb-8">Let's work <br /><span className="text-orange-500 underline decoration-4 underline-offset-8 transition-all hover:text-orange-400">together</span>.</h2>
              <p className="text-slate-400 text-lg mb-12 max-w-md">
                Interested in working on a project or just want to say hello? 
                Feel free to reach out via any of the channels.
              </p>
              
              <div className="space-y-8">
                <div className="flex items-center gap-6 group">
                  <div className="w-14 h-14 rounded-2xl bg-slate-800 flex items-center justify-center group-hover:bg-orange-500 transition-colors duration-300">
                    <Mail size={24} />
                  </div>
                  <div>
                    <p className="text-slate-500 text-sm font-bold uppercase tracking-widest">Email me at</p>
                    <a href="mailto:ahasanadib2005@gmail.com" className="text-xl font-medium hover:text-orange-500 transition-colors">ahasanadib2005@gmail.com</a>
                  </div>
                </div>
                
                <div className="flex items-center gap-6 group">
                  <div className="w-14 h-14 rounded-2xl bg-slate-800 flex items-center justify-center group-hover:bg-orange-500 transition-colors duration-300">
                    <Phone size={24} />
                  </div>
                  <div>
                    <p className="text-slate-500 text-sm font-bold uppercase tracking-widest">Call me at</p>
                    <a href="tel:+8801401894642" className="text-xl font-medium hover:text-orange-500 transition-colors">014-018-94642</a>
                  </div>
                </div>

                <div className="flex items-center gap-6 group">
                  <div className="w-14 h-14 rounded-2xl bg-slate-800 flex items-center justify-center group-hover:bg-orange-500 transition-colors duration-300">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <p className="text-slate-500 text-sm font-bold uppercase tracking-widest">Location</p>
                    <p className="text-xl font-medium">Uttara, Dhaka, Bangladesh</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-slate-800/50 backdrop-blur-sm p-10 rounded-[3rem] self-start border border-slate-700">
              <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-400 px-1">Name</label>
                  <input 
                    type="text" 
                    className="w-full bg-slate-900 border border-slate-700 rounded-2xl px-6 py-4 focus:outline-none focus:border-orange-500 transition-colors"
                    placeholder="Your Name"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-400 px-1">Email</label>
                  <input 
                    type="email" 
                    className="w-full bg-slate-900 border border-slate-700 rounded-2xl px-6 py-4 focus:outline-none focus:border-orange-500 transition-colors"
                    placeholder="your@email.com"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-400 px-1">Message</label>
                  <textarea 
                    rows={4}
                    className="w-full bg-slate-900 border border-slate-700 rounded-2xl px-6 py-4 focus:outline-none focus:border-orange-500 transition-colors resize-none"
                    placeholder="Tell me about your project..."
                  />
                </div>
                <button className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-5 rounded-2xl transition-all shadow-xl shadow-orange-500/20 active:scale-95">
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>

        <footer className="mt-32 pt-12 border-t border-slate-800 text-center text-slate-500 text-sm">
          <p>© {new Date().getFullYear()} Ahsan Habib Adib. Professional Portfolio.</p>
        </footer>
      </section>
    </div>
  );
}
